from setuptools import setup

setup(
    name='python_programming',
    version='1.0.0',
    packages=['lesson_package', 'lesson_package.talk', 'lesson_package.tools'],
    url='https://python_lesson.com',
    license='Free',
    author='kaitosato',
    author_email='xxx@xxx.com',
    description='Sample package'
)
