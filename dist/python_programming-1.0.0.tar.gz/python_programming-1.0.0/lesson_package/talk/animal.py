from lesson_package.tools import utils

def sing():
    return '##fjfjosfjieosfefsfa'

def cry():
    return utils.say_twice('sfojesia;ofjess')